﻿namespace AcademicoFOA2023.Models
{
    public class Filme
    {
        public long? FilmeID{ get; set; }
        public string Nome{ get; set; }
        public string Nota{ get; set; }
        public string Categoria{ get; set; }
    }
}
