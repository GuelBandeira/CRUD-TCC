﻿using AcademicoFOA2023.Models;
using Microsoft.AspNetCore.Mvc;

namespace AcademicoFOA2023.Controllers
{
    public class FilmeController : Controller
    {
        private static IList<Filme> filmes = new List<Filme>()
        {

        new Filme()
        {
            FilmeID = 1,
                Nome = "Senhor dos Anéis",
                Categoria = "Fantasia",
                Nota = "10"
        },

        new Filme()
        {
            FilmeID = 2,
                Nome = "Círculo de Fogo",
                Categoria = "Mecha",
                Nota = "8",
        }
    };
        public IActionResult Index()
        {
            return View(filmes);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Filme filme)
        {
            filme.FilmeID = filmes.Select(i => i.FilmeID).Max() + 1;
            filmes.Add(filme);
            return RedirectToAction("Index");
        }

        public ActionResult Edit(long id)
        {
            return View(filmes.Where(i => i.FilmeID == id).First());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Filme filme)
        {
            filmes.Remove(filmes.Where(i => i.FilmeID == filme.FilmeID).First());
            filmes.Add(filme);
            return RedirectToAction("Index");
        }

        public IActionResult Details(long id)
        {
            return View(filmes.Where(i => i.FilmeID == id).First());
        }

        public IActionResult Delete(long id)
        {
            return View(filmes.Where(i => i.FilmeID == id).First());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Delete(Filme filme)
        {
            filmes.Remove(filmes.Where(i => i.FilmeID == filme.FilmeID).First());
            return RedirectToAction("Index");
        }
    }
}
