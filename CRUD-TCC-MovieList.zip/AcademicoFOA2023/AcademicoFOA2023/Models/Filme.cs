﻿namespace AcademicoFOA2023.Models
{
    public class Filme
    {
        public long? FilmeID{ get; set; }
        public string Nome{ get; set; }
    }
}
